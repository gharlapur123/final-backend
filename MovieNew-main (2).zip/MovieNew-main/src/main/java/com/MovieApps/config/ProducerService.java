package com.MovieApps.config;

import com.MovieApps.model.Ticket;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {

    @Autowired
    private KafkaTemplate<String, String> temp;

    public void sentMessage(String message){
        //temp.send("MovieMessages", message);
    }

    public void saveTicket(Ticket ticket) {
        try {
            ObjectMapper obj = new ObjectMapper();
            String tic = obj.writeValueAsString(ticket);
            temp.send("MovieMessages", tic);
        } catch (Exception e) {
            System.out.println("Error Occured" + e);
        }
    }
}
