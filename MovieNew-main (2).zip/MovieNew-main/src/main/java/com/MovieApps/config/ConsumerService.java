package com.MovieApps.config;

import com.MovieApps.model.Ticket;
import com.MovieApps.repo.TicketRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class ConsumerService {

    @Autowired
    TicketRepository ticketRepository;

    @KafkaListener(topics = "MovieMessages", groupId = "group_id")
    public void consume(String ticket) {
        //System.out.println("Welcome to kafka Service "+ticket);
        try {
            ObjectMapper obj = new ObjectMapper();
            Ticket tic = obj.readValue(ticket, Ticket.class);
            ticketRepository.save(tic);
        } catch (Exception e) {
            System.out.println("Error Occured" + e);
        }
    }
}
